# Attendo
  <img align = "right" src = "https://github.com/Attendo-App/Attendo/blob/master/assets/images/icon-flat.png" width = 10%>
- Wifi based attendance for classrooms<br>
- A flutter application for streamlining the attendance marking procedure in classrooms. <br>
- A fast and secure way to mark attendance by using the local wifi and Alphanumeric code. <br>
- Developed as a project for the class CSN-291 <br>

[Design Doc](https://github.com/Org-Placeholder/Documents/blob/main/Attendo_design_doc.pdf)
