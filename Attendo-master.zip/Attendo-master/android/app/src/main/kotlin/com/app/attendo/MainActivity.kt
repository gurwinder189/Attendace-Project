package com.app.attendo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
