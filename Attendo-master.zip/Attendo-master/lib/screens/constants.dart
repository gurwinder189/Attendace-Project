import 'package:flutter/material.dart';

const PrimaryColor = Color(0xFF5B44C6);
const SecondaryColor = Color(0xFFB594E3);
const LightColor = Color(0xFFDEDBEF);
const DarkColor = Color(0xFF5E5D95);